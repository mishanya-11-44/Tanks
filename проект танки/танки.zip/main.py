import missiles_collection
from tkinter import*
import world
import tanks_collection
import texture
KEY_LEFT,KEY_RIGHT,KEY_UP,KEY_DOWN=37,39,38,40
KEY_W=87
KEY_S=83
KEY_A=65
KEY_D=68
KEY_SPACE=32
FPS=60
KEY_B=42
def update():
    tanks_collection.update()
    missiles_collection.update()
    player=tanks_collection.get_player()
    world.set_camera_xy(player.get_x()-world.SCREEN_WIDTH//2+player.get_size()//2,player.get_y()-world.SCREEN_HEIGHT//2+player.get_size()//2)
    world.update_map()
    w.after(1000//FPS,update)
def key_press(event):
    player=tanks_collection.get_player()
    if player.is_destroyed():
        return
    if event.keycode==KEY_W:
        player.forward()
    elif event.keycode==KEY_S:
        player.backward()
    elif event.keycode==KEY_A:
        player.left()
    elif event.keycode==KEY_D:
        player.right()
    elif event.keycode==KEY_UP:
        world.move_camera(0,-5)
    elif event.keycode==KEY_DOWN:
        world.move_camera(0,5)
    elif event.keycode==KEY_LEFT:
        world.move_camera(-5,0)
    elif event.keycode==KEY_RIGHT:
        world.move_camera(5,0)
    elif event.keycode==KEY_SPACE:
        player.fire()
def load_textures():
    texture.load('tank_up','../img/tank_up.png')
    texture.load('tank_down', '../img/tank_down.png')
    texture.load('tank_left', '../img/tank_left.png')
    texture.load('tank_right', '../img/tank_right.png')
    texture.load('tank_up_player', '../img/tank_up_player.png')
    texture.load('tank_down_player', '../img/tank_down_player.png')
    texture.load('tank_left_player', '../img/tank_left_player.png')
    texture.load('tank_right_player', '../img/tank_right_player.png')
    texture.load(world.BRICK,'../img/brick.png')
    texture.load(world.WATER, '../img/water.png')
    texture.load(world.CONCRETE, '../img/wall.png')
    texture.load(world.MISSLE, '../img/bonus.png')
    texture.load(world.NEW_BONUS,'../img/bonus2.png')
    texture.load(world.FUEL, '../img/bonus3.png')
    texture.load('missile_up','../img/missile_up.png')
    texture.load('missile_down', '../img/missile_down.png')
    texture.load('missile_left', '../img/missile_left.png')
    texture.load('missile_right', '../img/missile_right.png')
    texture.load('tank_destroyed','../img/tank_destroy.png')
    texture.load('hp_1','../img/здоровье1.png')
    texture.load('hp_2', '../img/здоровье2.png')
    texture.load('hp_3', '../img/здоровье3.png')
    texture.load('hp_4', '../img/здоровье4.png')
    texture.load('hp_5', '../img/здоровье5.png')
w=Tk()
w.title='Танки на минималках 2.0'
canv=Canvas(w, width=world.SCREEN_WIDTH, height=world.SCREEN_HEIGHT, bg='#8ccb5e')
canv.pack()
load_textures()
world.initialize(canv)
tanks_collection.initialise(canv)
missiles_collection.initialize(canv)
w.bind('<KeyPress>', key_press)
update()
w.mainloop()